# emailid_finder Package

This will find email-id is fake or not
[Github-flavored Markdown](https://github.com/uthum/emailid_finder/blob/master/README.md)
to write your content.